import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/product.dart';

/// Capa de acceso a la Fake Store API para todo lo relacionado al
/// catálogo de productos (US03) y su filtrado por categoría (US04).
///
/// Responsabilidad única: hablar HTTP con https://fakestoreapi.com.
/// No conoce nada de UI ni de reglas de negocio (eso vive en el controller).
class ProductApiService {
  static const String _baseUrl = 'https://fakestoreapi.com';

  /// GET /products — catálogo completo (US03, Escenario 1).
  Future<List<Product>> getAllProducts() => _getProductList('$_baseUrl/products');

  /// GET /products/categories — categorías disponibles (US04, Escenario 1).
  Future<List<String>> getCategories() async {
    final uri = Uri.parse('$_baseUrl/products/categories');
    final response = await _get(uri);
    final List<dynamic> data = jsonDecode(response.body);
    return data.map((e) => e.toString()).toList();
  }

  /// GET /products/category/{category} — productos filtrados (US04, Escenario 2).
  Future<List<Product>> getProductsByCategory(String category) {
    final encoded = Uri.encodeComponent(category);
    return _getProductList('$_baseUrl/products/category/$encoded');
  }

  Future<List<Product>> _getProductList(String url) async {
    final response = await _get(Uri.parse(url));
    final List<dynamic> data = jsonDecode(response.body);
    return data
        .map((e) => Product.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<http.Response> _get(Uri uri) async {
    late http.Response response;
    try {
      response = await http.get(uri).timeout(const Duration(seconds: 15));
    } catch (_) {
      throw ProductApiException(
        'Ocurrió un error de red. Verifica tu conexión e inténtalo de nuevo.',
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ProductApiException('Error del servidor (${response.statusCode}).');
    }

    return response;
  }
}

class ProductApiException implements Exception {
  final String message;
  ProductApiException(this.message);
  @override
  String toString() => message;
}
